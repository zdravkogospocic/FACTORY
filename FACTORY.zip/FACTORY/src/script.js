jQuery(document).ready(function ($) {
  const slideLeft = () => {
    let topFirstSlide = $('.top-row img:first');
    let bottomFirstSlide = $('.bottom-row img:first');
    let topFirstSlideWidth = $('.top-row img:first').width();
    let bottomFirstSlideWidth = $('.bottom-row img:first').width();

    $('.top-row img:first').animate(
      {
        width: '0',
      },
      100
    );
    $('.bottom-row img:first').animate(
      {
        width: '0',
      },
      100
    );

    setTimeout(function () {
      $('.top-row img:first').remove();
      $('.top-row img:last').after(topFirstSlide);
      $('.bottom-row img:first').remove();
      $('.bottom-row img:last').after(bottomFirstSlide);
    }, 150);

    setTimeout(function () {
      $('.top-row img:last').animate(
        {
          width: `${topFirstSlideWidth}`,
        },
        100
      );
      $('.bottom-row img:last').animate(
        {
          width: `${bottomFirstSlideWidth}`,
        },
        100
      );
    }, 200);
  };

  const slideRight = () => {
    let topLastSlide = $('.top-row img:last');
    let bottomLastSlide = $('.bottom-row img:last');
    let topLastSlideWidth = $('.top-row img:last').width();
    let bottomLastSlideWidth = $('.bottom-row img:last').width();

    $('.top-row img:last').animate(
      {
        width: '0',
      },
      100
    );
    $('.bottom-row img:last').animate(
      {
        width: '0',
      },
      100
    );

    setTimeout(function () {
      $('.top-row img:last').remove();
      $('.top-row img:first').before(topLastSlide);
      $('.bottom-row img:last').remove();
      $('.bottom-row img:first').before(bottomLastSlide);
    }, 150);

    setTimeout(function () {
      $('.top-row img:first').animate(
        {
          width: `${topLastSlideWidth}`,
        },
        100
      );
      $('.bottom-row img:first').animate(
        {
          width: `${bottomLastSlideWidth}`,
        },
        100
      );
    }, 200);
  };

  const leftButton = $('.arrows .arrows__left');

  const rightButton = $('.arrows .arrows__right');

  leftButton.on('click', function () {
    slideLeft();
  });

  rightButton.on('click', function () {
    slideRight();
  });
});
